<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_'))
    exit;

define('CULQI_SDK_VERSION', '1.3.0');

/**
 * Calling dependencies
 */
include_once dirname(__FILE__).'/libraries/Requests/library/Requests.php';

Requests::register_autoloader();

include_once dirname(__FILE__).'/libraries/culqi-php/lib/culqi.php';


class Culqi extends PaymentModule
{

    private $_postErrors = array();

    /**
     *
     * Constructor del módulo
     *
     * @return void
     */
    public function __construct()
    {
        $this->name = 'culqi';
        $this->tab = 'payments_gateways';
        $this->version = '3.0.4';
        $this->controllers = array('chargeajax','postpayment');
        $this->author = 'Team Culqi (Willy Aguirre, Brayan Cruces, Liz Ruelas)';
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->bootstrap = true;
        $this->display = 'view';
        $this->domain = Tools::getShopDomainSsl(true, true).__PS_BASE_URI__;
        $this->url_return = $this->domain.'index.php?fc=module&module='.$this->name.'&controller=webhookOrderStatusChanged';
        $this->module_key = '';

        parent::__construct();

        $this->meta_title = 'Culqi';
        $this->displayName = 'Culqi';
        $this->description = $this->l('Acepta tarjetas de crédito y débito en tu tienda online.');
        $this->confirmUninstall = $this->l('¿Estás seguro que quieres desintalar el módulo de Culqi?');

    }

    /**
     *
     * Registra el módulo en los hooks correspondientes y elimina los valores anteriores de llaves de Culqi
     *
     * @return void
     */
    public function install()
    {
        $this->createStates();

        return (
            parent::install() &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('paymentReturn') &&
            Configuration::updateValue('CULQI_LLAVE_SECRETA', '') &&
            Configuration::updateValue('CULQI_LLAVE_PUBLICA', '') &&
            Configuration::updateValue('CULQI_WEBHOOK_ORDER_STATUS_CHANGED', $this->url_return)
        );
    }

    /**
     *
     * Obtiene el número de telefono
     */
    private function getPhone($address)
    {
        if(empty($address->phone_mobile))
        {
            return $address->phone;
        } else {
            return $address->phone_mobile;
        }
    }

    /**
     * @deprecated
     *
     * Esta funcion no se llama en ningun momento dentro del módulo
     */
    private function getCustomerId()
    {
        if ($this->context->customer->isLogged())
        {
            return (int) $this->context->customer->id;
        } else {
            return 0;
        }
    }

     /**
     * @deprecated
     *
     * Esta funcion no se llama en ningun momento dentro del módulo
     */
    public function errorPayment($mensaje)
    {
        $smarty = $this->context->smarty;
        $smarty->assign('culqi_error_pago', $mensaje);
    }

    /**
     *
     * Se crea un Cargo con la nueva api v3 de Culqi PHP
     *
     * @return void
     */
    public function orderCulqi()
    {
        try {
            $cart = $this->context->cart;
            $userAddress = new Address((int)$cart->id_address_invoice);

            $culqi = new Culqi\Culqi(array('api_key' => Configuration::get('CULQI_LLAVE_SECRETA')));
            $orderCulqi = $culqi->Orders->create(
                array(
                    "amount" => $this->removeComma($cart->getOrderTotal(true, Cart::BOTH)),
                    "currency_code" => $this->context->currency->iso_code,
                    "description" => "Orden de compra ".$cart->id,
                    "order_number" => "#id-".rand(1,9999),
                    "client_details" => array(
                        "first_name" => $this->context->customer->firstname,
                        "last_name" => $this->context->customer->lastname,
                        "phone_number" => $this->getPhone($userAddress) ?: 999999999,
                        "email" => $this->context->customer->email,
                    ),
                    "expiration_date" => time() + 24*60*60,   // Orden con un dia de validez
                    "confirm" => false
                )
            );
            return $orderCulqi;
        } catch(Exception $e){
            return $e->getMessage();
        }

    }

    /**
    *
    * Se crea un Cargo con la nueva api v2 de Culqi PHP
    *
    * @param  string  $token_id Contiene el token generado por la Api de culqi
    * @param  int  $installments Cuotas en las que desea financiar su pago
    *
    * @return object
    */
    public function charge($token_id, $installments)
    {
      try {

        $cart = $this->context->cart;

        $userAddress = new Address((int)$cart->id_address_invoice);
        $userCountry = new Country((int)$userAddress->id_country);

        $culqi = new Culqi\Culqi(array('api_key' => Configuration::get('CULQI_LLAVE_SECRETA')));

        $charge = $culqi->Charges->create(
            array(
              "amount" => $this->removeComma($cart->getOrderTotal(true, Cart::BOTH)),
              "antifraud_details" => array(
                  "address" => empty($userAddress->address1) ? $userAddress->address2 : $userAddress->address1,
                  "address_city" => $userAddress->city,
                  "country_code" => "PE",
                  "first_name" => $this->context->customer->firstname,
                  "last_name" => $this->context->customer->lastname,
                  "phone_number" => $this->getPhone($userAddress) ?: 999999999,
              ),
              "capture" => true,
              "currency_code" => $this->context->currency->iso_code,
              "description" => "Orden de compra ".$cart->id,
              "installments" => $installments,
              "metadata" => ["cart_id" => (string)$cart->id ],
              "email" => $this->context->customer->email,
              "source_id" => $token_id
            )
        );

        return $charge;
      } catch(Exception $e){
        return $e->getMessage();
      }

    }

    /**
     *
     * Hook de Prestashop para mostrar el método de pago
     *
     * @param array $params recibo los parámetros de prestashop
     *
     * @return array
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active)
        {
          return;
        }
        if (!$this->checkCurrency($params['cart']))
        {
          return;
        }

        $newOption = new PaymentOption();

        $this->context->smarty->assign(
          $this->getCulqiInfoCheckout()
        );

        $newOption->setModuleName($this->name)
                  ->setCallToActionText($this->trans('Pagar con Tarjeta', array(), 'culqi'))
                  ->setAdditionalInformation($this->context->smarty->fetch('module:culqi/views/templates/hook/payment.tpl'))
                  ->setLogo(Media::getMediaPath($this->domain.'modules/'.$this->name.'/views/img/logo_cards.png'));;

        $payment_options = [
            $newOption,
        ];

        return $payment_options;
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }

        $currentState = $params['order']->getCurrentState();

        $in_array = in_array(
            $currentState,
            array(
                Configuration::get('CULQI_STATE_OK'),
                Configuration::get('CULQI_STATE_PENDING'),
                Configuration::get('CULQI_STATE_ERROR')
            )
        );

        switch ($currentState) {
            case Configuration::get('CULQI_STATE_OK'):
                $paymentState['code'] = 'OKS';
                $paymentState['icon'] = 'done_all';
                $paymentState['cip'] = '';
                $paymentState['description'] = 'Pago registrado correctamente';
                break;

            case Configuration::get('CULQI_STATE_PENDING'):
                $paymentState['code'] = 'PND';
                $paymentState['icon'] = 'hourglass_empty';
                $paymentState['cip'] = Tools::getValue('cip');
                $paymentState['description'] = 'Pendiente de pago';
                break;

            default:
                $paymentState['code'] = 'ERR';
                $paymentState['icon'] = 'error';
                $paymentState['cip'] = '';
                $paymentState['description'] = 'Error de pago';
                break;
        }

        if ($in_array) {
            $this->smarty->assign([
                'status' =>'ok',
                'paymentState' => $paymentState,
            ]);
        } else {
            $this->smarty->assign('status', 'failed');
        }

        $this->context->controller->addJS([$this->_path . 'views/js/confirmation.js']);

        return $this->display(__FILE__, 'confirmation.tpl');
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency((int)($cart->id_currency));
        $currencies_module = $this->getCurrency((int)$cart->id_currency);

        if (is_array($currencies_module))
        {
          foreach ($currencies_module as $currency_module)
          {
            if ($currency_order->id == $currency_module['id_currency'])
            {
              return true;
            }
          }
        }

        return false;
    }

    public function getCulqiInfoCheckout(){
        $cart = $this->context->cart;
        $orderCulqi = $this->orderCulqi();

        return [
            "module_dir" => $this->_path,
            'logo' => $this->domain.'img/'.Configuration::get('PS_LOGO'),
            "descripcion" => "Orden de compra ".$cart->id,
            "orden" => $cart->id,
            "orden" => $cart->id,
            'order_culqi' => $orderCulqi,
            "total" => $this->removeComma($cart->getOrderTotal(true, Cart::BOTH)),
            "llave_publica" => Configuration::get('CULQI_LLAVE_PUBLICA'),
            "currency" => $this->context->currency->iso_code
        ];
    }

    /**
     * @deprecated
     *
     * No se debe elminar el id_order_state por que pueden haber pedidos con ese método de pago y estarán corruptos
     * si llegan a eliminarlo.
     */
    public function uninstallStates()
    {
        if (Db::getInstance()->Execute("DELETE FROM " . _DB_PREFIX_ . "order_state WHERE id_order_state = ( SELECT value
                FROM " . _DB_PREFIX_ . "configuration WHERE name =  'CULQI_STATE_OK' )") &&
            Db::getInstance()->Execute("DELETE FROM " . _DB_PREFIX_ . "order_state_lang WHERE id_order_state = ( SELECT value
                FROM " . _DB_PREFIX_ . "configuration WHERE name =  'CULQI_STATE_OK' )") &&
            Db::getInstance()->Execute("DELETE FROM " . _DB_PREFIX_ . "order_state WHERE id_order_state = ( SELECT value
                FROM " . _DB_PREFIX_ . "configuration WHERE name =  'CULQI_STATE_ERROR' )") &&
            Db::getInstance()->Execute("DELETE FROM " . _DB_PREFIX_ . "order_state_lang WHERE id_order_state = ( SELECT value
                FROM " . _DB_PREFIX_ . "configuration WHERE name =  'CULQI_STATE_ERROR' )")
        ) return true;
        return false;
    }

    /**
     *
     * Elimina los valores generados en el módilo
     *
     * @return bool
     */
    public function uninstall()
    {
        if (!parent::uninstall()
        || !Configuration::deleteByName('CULQI_LLAVE_SECRETA')
        || !Configuration::deleteByName('CULQI_LLAVE_PUBLICA')
        || !Configuration::deleteByName('CULQI_WEBHOOK_CATCH_LOG'))
        // || !$this->uninstallStates())
            return false;
        return true;
    }

    /**
     *
     * Valida los campos de la configuración del módulo en el backoffice antes de guardar.
     */
    private function _postValidation()
    {
        if (Tools::isSubmit('btnSubmit'))
        {
            if (!Tools::getValue('CULQI_LLAVE_SECRETA'))
            {
              $this->_postErrors[] = $this->l('El campo llave de comercio es requerido.');
            }

            if (!Tools::getValue('CULQI_LLAVE_PUBLICA'))
            {
              $this->_postErrors[] = $this->l('El campo código de comercio es requerido.');
            }
        }
    }

    public function getContent()
    {

        $this->_html = '';

        if (Tools::isSubmit('btnSubmit'))
        {
            $this->_postValidation();
            if (!count($this->_postErrors))
            {
              $this->_postProcess();
            } else {
              foreach ($this->_postErrors as $err) {
                $this->_html .= $this->displayError($err);
              }
            }
        }

        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    /**
     *
     * Crea los estados de pago en las tablas de Prestashop, en caso
     * ya existan no las generará
     *
     * @return void
     */
    private function createStates()
    {
        if (!Configuration::get('CULQI_STATE_OK')) {
            $order_state = new OrderState();
            $order_state->name = array();
            foreach (Language::getLanguages() as $language) {
              $order_state->name[$language['id_lang']] = 'Exitoso';
            }
            $order_state->send_email = false;
            $order_state->color = '#39CC98';
            $order_state->hidden = false;
            $order_state->paid = true;
            $order_state->module_name = 'culqi';
            $order_state->delivery = false;
            $order_state->logable = false;
            $order_state->invoice = true;
            $order_state->pdf_invoice = true;
            $order_state->add();
            Configuration::updateValue('CULQI_STATE_OK', (int)$order_state->id);
        }

        if (!Configuration::get('CULQI_STATE_PENDING')) {
            $order_state = new OrderState();
            $order_state->name = array();
            foreach (Language::getLanguages() as $language) {
                $order_state->name[$language['id_lang']] = 'Pendiente de pago';
            }
            $order_state->send_email = false;
            $order_state->color = '#d3f237';
            $order_state->module_name = 'culqi';
            $order_state->hidden = false;
            $order_state->delivery = false;
            $order_state->logable = false;
            $order_state->invoice = false;
            $order_state->add();
            Configuration::updateValue('CULQI_STATE_PENDING', (int)$order_state->id);
        }

        if (!Configuration::get('CULQI_STATE_EXPIRED')) {
            $order_state = new OrderState();
            $order_state->name = array();
            foreach (Language::getLanguages() as $language) {
                $order_state->name[$language['id_lang']] = 'Orden expirada';
            }
            $order_state->send_email = false;
            $order_state->color = '#9ea095';
            $order_state->module_name = 'culqi';
            $order_state->hidden = false;
            $order_state->delivery = false;
            $order_state->logable = false;
            $order_state->invoice = false;
            $order_state->add();
            Configuration::updateValue('CULQI_STATE_EXPIRED', (int)$order_state->id);
        }

        if (!Configuration::get('CULQI_STATE_ERROR')) {
            $order_state = new OrderState();
            $order_state->name = array();
            foreach (Language::getLanguages() as $language) {
                $order_state->name[$language['id_lang']] = 'Incorrecto';
            }
            $order_state->send_email = false;
            $order_state->color = '#FF2843';
            $order_state->module_name = 'culqi';
            $order_state->hidden = false;
            $order_state->delivery = false;
            $order_state->logable = false;
            $order_state->invoice = false;
            $order_state->add();
            Configuration::updateValue('CULQI_STATE_ERROR', (int)$order_state->id);
        }
    }

    /**
     *
     * Genera la vista "Configuración" dentro del módulo de cullqi en Prestashop
     *
     * @return array
     */
    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('CONFIGURACIONES GENERALES CULQI'),
                    'icon' => 'icon-money'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Llave Pública'),
                        'name' => 'CULQI_LLAVE_PUBLICA',
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Llave Secreta'),
                        'name' => 'CULQI_LLAVE_SECRETA',
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Webhook PagoEfectivo'),
                        'name' => 'CULQI_WEBHOOK_ORDER_STATUS_CHANGED',
                        'desc' => 'Copia esta url en el Webhook del panel de Culqi en la opción "order.status.changed"'
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Capturar log de Webservice'),
                        'desc' => 'Captura todas las respuestas de culqi en un archivo <a target="_blank" href="'. $this->domain.'modules/'.$this->name .'/logs/webhook.txt"> webhook.txt </a> ',
                        'name' => 'CULQI_WEBHOOK_CATCH_LOG',
                        'is_bool' => true,
                        'required' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('No')
                            )
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Guardar'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
        return array(
            'CULQI_LLAVE_SECRETA' => Tools::getValue('CULQI_LLAVE_SECRETA', Configuration::get('CULQI_LLAVE_SECRETA')),
            'CULQI_LLAVE_PUBLICA' => Tools::getValue('CULQI_LLAVE_PUBLICA', Configuration::get('CULQI_LLAVE_PUBLICA')),
            'CULQI_WEBHOOK_CATCH_LOG' => Tools::getValue('CULQI_WEBHOOK_CATCH_LOG', Configuration::get('CULQI_WEBHOOK_CATCH_LOG')),
            'CULQI_WEBHOOK_ORDER_STATUS_CHANGED' => $this->url_return

        );
    }

    /**
     *
     * Guarda los campos del módulo de culqi
     *
     * @return array
     */
    private function _postProcess()
    {
        if (Tools::isSubmit('btnSubmit'))
        {
            Configuration::updateValue('CULQI_LLAVE_SECRETA', Tools::getValue('CULQI_LLAVE_SECRETA'));
            Configuration::updateValue('CULQI_LLAVE_PUBLICA', Tools::getValue('CULQI_LLAVE_PUBLICA'));
            Configuration::updateValue('CULQI_WEBHOOK_CATCH_LOG', Tools::getValue('CULQI_WEBHOOK_CATCH_LOG'));
        }
        $this->_html .= $this->displayConfirmation($this->l('Se actualizaron las configuraciones'));
    }

    /**
     *
     * Elimina las comas de una cadena de texto
     *
     * @param string $amount importe del pago a culqi
     *
     * @return string
     */
    public function removeComma($amount) {
        return str_replace(".","",str_replace(',', '', number_format($amount,2,'.',',')));
    }

  }


class CulqiPago
{
    public static $llaveSecreta;
    public static $codigoComercio;
}
